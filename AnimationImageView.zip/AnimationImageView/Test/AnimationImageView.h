//
//  AnimationImageView.h
//  Test
//
//  Created by apple on 2021/7/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AnimationImageView : UIImageView

/**
 飘动动画初始化
 @param image 飘动图片
 @param frame 图片frame
 @param disappearArea 消失区域
 */
- (instancetype)initWithImage:(UIImage *)image
                        frame:(CGRect)frame
                disappearArea:(CGRect)disappearArea;

- (void)showAnimationInSuperView:(UIView *)superView;

@end

NS_ASSUME_NONNULL_END
