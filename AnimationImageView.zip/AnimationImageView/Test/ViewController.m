//
//  ViewController.m
//  Test
//
//  Created by apple on 2021/2/23.
//

#import "ViewController.h"

#import "AnimationImageView.h"

@interface ViewController ()

@property (strong, nonatomic) UIButton *button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
 
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    _button.backgroundColor = [UIColor whiteColor];
    [_button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_button setTitle:@"点击展示飘出动画" forState:UIControlStateNormal];
    _button.frame = CGRectMake(80, 500, 200, 40);
    [self.view addSubview:_button];
    [_button addTarget:self action:@selector(_animationClick) forControlEvents:UIControlEventTouchUpInside];
}

- (void)_animationClick {
    CGSize imageSize = CGSizeMake(45, 45);
    CGRect originFrame = CGRectMake(_button.frame.origin.x + (_button.frame.size.width - imageSize.width) * 0.5, _button.frame.origin.y + 9, imageSize.width, imageSize.height);
    UIImage *image = [UIImage imageNamed:@"textImg.png"];
    CGRect disappearArea = originFrame;
    disappearArea.origin.y -= 50;
    disappearArea.size = CGSizeMake([[UIScreen mainScreen] bounds].size.width, originFrame.size.height);
    AnimationImageView *view = [[AnimationImageView alloc] initWithImage:image frame:originFrame disappearArea:disappearArea];
    [view showAnimationInSuperView:self.view];
}


@end
