//
//  AnimationImageView.m
//  Test
//
//  Created by apple on 2021/7/23.
//

#define kScreenWidth [[UIScreen mainScreen] bounds].size.width

#import "AnimationImageView.h"

@interface AnimationImageView () <CAAnimationDelegate>

@property (nonatomic, assign) CGRect disappearArea;

@end

@implementation AnimationImageView

- (instancetype)initWithImage:(UIImage *)image
                        frame:(CGRect)frame
                disappearArea:(CGRect)disappearArea {
    if (self = [super initWithImage:image]) {
        self.frame = frame;
        self.disappearArea = disappearArea;
    }
    return self;
}

- (void)showAnimationInSuperView:(UIView *)superView {
    [superView addSubview:self];
    
    NSInteger forward = (arc4random() % 2 == 1) ? 1 : -1;
    CGPoint orginPoint = self.center;
    CGFloat startY = orginPoint.y - 60;
    CGFloat verticalInterval = (self.disappearArea.origin.y - startY)/3.0f;
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    CGPoint startPoint = CGPointMake(orginPoint.x, startY);
    [path moveToPoint:startPoint];
    
    CGPoint controlPoint1 = CGPointMake([self getXPositionWithStartX:startPoint.x forward:forward], startPoint.y+verticalInterval);
    CGPoint controlPoint2 = CGPointMake([self getXPositionWithStartX:startPoint.x forward:-forward], controlPoint1.y+verticalInterval);
    CGPoint endPoint = CGPointMake([self getXPositionWithStartX:startPoint.x forward:forward], controlPoint2.y+verticalInterval);
    [path addCurveToPoint:endPoint controlPoint1:controlPoint1 controlPoint2:controlPoint2];
    
    CGFloat duration = 3.0f;
    
    CAKeyframeAnimation *pathAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    pathAnimation.path = path.CGPath;
    pathAnimation.duration = duration;
    pathAnimation.fillMode = kCAFillModeForwards;
    pathAnimation.delegate = self;
    [self.layer addAnimation:pathAnimation forKey:@"path"];
    
    self.alpha = 0;
    
    [UIView animateWithDuration:(duration/10)*0.7 animations:^{
        self.transform = CGAffineTransformMakeScale(1.2, 1.2);
        self.alpha = .8f;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:(duration/10)*0.7 animations:^{
            self.transform = CGAffineTransformMakeScale(1.0, 1.0);
            self.alpha = 1;
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:(duration/10)*8.6 animations:^{
                self.alpha = 0;
            }];
        }];
    }];
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    if (flag) {
        [self removeFromSuperview];
    }
}

#pragma mark - private

- (CGFloat)getXPositionWithStartX:(CGFloat)startX forward:(NSInteger)forward {
    CGFloat xPosition = startX + (forward * [self randomNumberFromZeroToHundred]);
    return [self correctXPosition:xPosition];
}

- (CGFloat)correctXPosition:(CGFloat)xPosition {
    CGFloat halfWidth = self.frame.size.width/2.0f;
    if (xPosition - halfWidth < 0) {
        xPosition = 0;
    } else if ((xPosition + halfWidth) > kScreenWidth) {
        xPosition = kScreenWidth - self.frame.size.width;
    }
    return xPosition;
}

- (NSInteger)randomNumberFromZeroToHundred {
    NSInteger number = arc4random() % 100;
    return number;
}

@end
